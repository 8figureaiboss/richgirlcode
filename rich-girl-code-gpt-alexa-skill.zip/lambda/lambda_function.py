
def lambda_handler(event, context):
    request_type = event['request']['type']
    if request_type == "LaunchRequest":
        return {
            'version': '1.0',
            'response': {
                'outputSpeech': {
                    'type': 'PlainText',
                    'text': 'Welcome to Rich Girl Coach. Ask me about business credit or investing!'
                },
                'shouldEndSession': False
            }
        }
