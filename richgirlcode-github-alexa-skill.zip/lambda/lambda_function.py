
def lambda_handler(event, context):
    request_type = event['request']['type']
    if request_type == "LaunchRequest":
        return {
            'version': '1.0',
            'response': {
                'outputSpeech': {
                    'type': 'PlainText',
                    'text': 'Welcome to Rich Girl Mentor. I can help with credit, funding, and investment insights.'
                },
                'shouldEndSession': False
            }
        }
    elif request_type == "IntentRequest":
        intent_name = event['request']['intent']['name']
        if intent_name == "GetBusinessCreditTips":
            response_text = "To build business credit, start with Net-30 vendors like Quill and Uline."
        elif intent_name == "GetFundingHelp":
            response_text = "You can explore business lines of credit, Fundbox, or secured cards to start."
        elif intent_name == "GetInvestmentStrategy":
            response_text = "Consider dividend ETFs like SCHD, VYM, or JEPI for cash flow."
        else:
            response_text = "Sorry, I don't know that yet."
        return {
            'version': '1.0',
            'response': {
                'outputSpeech': {
                    'type': 'PlainText',
                    'text': response_text
                },
                'shouldEndSession': False
            }
        }
